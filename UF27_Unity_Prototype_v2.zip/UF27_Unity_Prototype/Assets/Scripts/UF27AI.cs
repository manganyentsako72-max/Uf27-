using UnityEngine;

public class UF27AI : MonoBehaviour
{
    public Transform ball;
    void Update()
    {
        if(!ball) return;
        Vector3 target=new Vector3(ball.position.x,1,Mathf.Min(ball.position.z+2f,14f));
        transform.position=Vector3.MoveTowards(transform.position,target,2.2f*Time.deltaTime);
        if(Vector3.Distance(transform.position,ball.position)<1.2f)
            ball.GetComponent<Rigidbody>().AddForce(Vector3.back*3f+Vector3.up*.5f,ForceMode.Impulse);
    }
}
