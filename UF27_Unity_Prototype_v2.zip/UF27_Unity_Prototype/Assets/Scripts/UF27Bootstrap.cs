using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class UF27Bootstrap : MonoBehaviour
{
    public static UF27Bootstrap I;
    public int homeScore, awayScore;
    public float matchTime = 0f;
    public bool matchRunning = true;
    Text scoreText, clockText, messageText;
    UF27PlayerController player;
    Transform ball;
    Rigidbody ballBody;
    readonly List<Transform> awayPlayers = new List<Transform>();

    void Awake() { I = this; }
    void Start()
    {
        Application.targetFrameRate = 60;
        BuildPitch();
        BuildBall();
        BuildTeams();
        BuildCamera();
        BuildUI();
    }

    Material Mat(Color c) { var m = new Material(Shader.Find("Universal Render Pipeline/Lit")); if (m.shader == null) m.shader = Shader.Find("Standard"); m.color = c; return m; }

    void BuildPitch()
    {
        var green = Mat(new Color(.08f,.38f,.16f));
        var white = Mat(Color.white);
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Pitch"; ground.transform.position = new Vector3(0,-.25f,0);
        ground.transform.localScale = new Vector3(22,.5f,34); ground.GetComponent<Renderer>().material = green;
        Destroy(ground.GetComponent<Collider>());
        Line(new Vector3(-10.5f,.02f,0),new Vector3(10.5f,.02f,0),white);
        Line(new Vector3(-10.5f,.02f,-16.5f),new Vector3(10.5f,.02f,-16.5f),white);
        Line(new Vector3(-10.5f,.02f,16.5f),new Vector3(10.5f,.02f,16.5f),white);
        Line(new Vector3(-10.5f,.02f,-16.5f),new Vector3(-10.5f,.02f,16.5f),white);
        Line(new Vector3(10.5f,.02f,-16.5f),new Vector3(10.5f,.02f,16.5f),white);
        var circle = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        circle.transform.position = new Vector3(0,.015f,0); circle.transform.localScale = new Vector3(8,.01f,8);
        circle.GetComponent<Renderer>().material = white; Destroy(circle.GetComponent<Collider>());
        var inner = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        inner.transform.position = new Vector3(0,.025f,0); inner.transform.localScale = new Vector3(7.85f,.01f,7.85f);
        inner.GetComponent<Renderer>().material = green; Destroy(inner.GetComponent<Collider>());
        Goal(-17.2f); Goal(17.2f);
    }

    void Line(Vector3 a, Vector3 b, Material m)
    {
        var g = new GameObject("Pitch marking"); var lr = g.AddComponent<LineRenderer>();
        lr.positionCount=2; lr.SetPosition(0,a); lr.SetPosition(1,b); lr.startWidth=.07f; lr.endWidth=.07f;
        lr.material=m; lr.useWorldSpace=true;
    }

    void Goal(float z)
    {
        var mat = Mat(Color.white);
        Vector3 a=new Vector3(-3,.05f,z), b=new Vector3(3,.05f,z), c=new Vector3(-3,2.3f,z), d=new Vector3(3,2.3f,z);
        Line(a,b,mat); Line(a,c,mat); Line(b,d,mat); Line(c,d,mat);
    }

    GameObject MakePlayer(string label, Vector3 pos, Color shirt, bool isUser=false)
    {
        var p=GameObject.CreatePrimitive(PrimitiveType.Capsule);
        p.name=label; p.transform.position=pos; p.transform.localScale=new Vector3(.8f,1.1f,.8f);
        p.GetComponent<Renderer>().material=Mat(shirt);
        if(isUser) { player=p.AddComponent<UF27PlayerController>(); player.ball=ball; }
        else if(pos.z<0) { var ai=p.AddComponent<UF27AI>(); ai.ball=ball; }
        return p;
    }

    void BuildTeams()
    {
        MakePlayer("UF27 Striker",new Vector3(0,1,-5),new Color(.1f,.35f,1),true);
        MakePlayer("Blue teammate 2",new Vector3(-5,1,-9),new Color(.1f,.35f,1));
        MakePlayer("Blue teammate 3",new Vector3(5,1,-10),new Color(.1f,.35f,1));
        MakePlayer("Blue teammate 4",new Vector3(0,1,-13),new Color(.1f,.35f,1));
        MakePlayer("Red defender 1",new Vector3(-3,1,4),new Color(.85f,.12f,.12f));
        MakePlayer("Red defender 2",new Vector3(3,1,7),new Color(.85f,.12f,.12f));
        MakePlayer("Red defender 3",new Vector3(0,1,11),new Color(.85f,.12f,.12f));
        MakePlayer("Red goalkeeper",new Vector3(0,1,15),new Color(.95f,.75f,.1f));
    }

    void BuildBall()
    {
        var b=GameObject.CreatePrimitive(PrimitiveType.Sphere);
        b.name="Match ball"; b.transform.position=new Vector3(0,.5f,-3); b.transform.localScale=Vector3.one*.55f;
        b.GetComponent<Renderer>().material=Mat(Color.white);
        ballBody=b.AddComponent<Rigidbody>(); ballBody.mass=.45f; ballBody.drag=.15f; ballBody.angularDrag=.08f;
        ball=b.transform;
    }

    void BuildCamera()
    {
        var cam=Camera.main;
        if(!cam) { var g=new GameObject("Main Camera"); cam=g.AddComponent<Camera>(); }
        cam.transform.position=new Vector3(0,18,-23); cam.transform.rotation=Quaternion.Euler(38,0,0);
        cam.fieldOfView=60; cam.backgroundColor=new Color(.08f,.12f,.16f);
        cam.gameObject.AddComponent<AudioListener>();
    }

    void BuildUI()
    {
        var canvasGO=new GameObject("UF27 HUD"); var canvas=canvasGO.AddComponent<Canvas>();
        canvas.renderMode=RenderMode.ScreenSpaceOverlay; canvasGO.AddComponent<CanvasScaler>().uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvasGO.AddComponent<GraphicRaycaster>();
        var ev=new GameObject("EventSystem"); ev.AddComponent<EventSystem>(); ev.AddComponent<StandaloneInputModule>();
        scoreText=Label(canvas.transform,"BLUE  0  -  0  RED",new Vector2(.5f,.95f),new Vector2(430,60),30);
        clockText=Label(canvas.transform,"00:00",new Vector2(.5f,.88f),new Vector2(160,40),22);
        messageText=Label(canvas.transform,"UF27 • PROTOTYPE",new Vector2(.5f,.08f),new Vector2(350,35),16);
        HoldButtonUI(canvas.transform,"▲",new Vector2(.12f,.22f),new Vector2(70,70),0,1);
        HoldButtonUI(canvas.transform,"▼",new Vector2(.12f,.07f),new Vector2(70,70),0,-1);
        HoldButtonUI(canvas.transform,"◀",new Vector2(.045f,.145f),new Vector2(70,70),-1,0);
        HoldButtonUI(canvas.transform,"▶",new Vector2(.195f,.145f),new Vector2(70,70),1,0);
        ButtonUI(canvas.transform,"SHOOT",new Vector2(.88f,.15f),new Vector2(110,75),()=>player.Shoot());
        ButtonUI(canvas.transform,"PASS",new Vector2(.76f,.08f),new Vector2(90,60),()=>player.Pass());
        HoldButtonUI(canvas.transform,"SPRINT",new Vector2(.89f,.28f),new Vector2(100,60),0,0,true);
    }

    Text Label(Transform parent,string value,Vector2 anchor,Vector2 size,int font)
    {
        var g=new GameObject(value); g.transform.SetParent(parent,false); var t=g.AddComponent<Text>();
        t.text=value; t.font=Resources.GetBuiltinResource<Font>("Arial.ttf"); t.fontSize=font; t.alignment=TextAnchor.MiddleCenter; t.color=Color.white;
        var r=g.GetComponent<RectTransform>(); r.anchorMin=anchor; r.anchorMax=anchor; r.anchoredPosition=Vector2.zero; r.sizeDelta=size; return t;
    }

    void ButtonUI(Transform parent,string value,Vector2 anchor,Vector2 size,UnityEngine.Events.UnityAction action)
    {
        var g=new GameObject(value); g.transform.SetParent(parent,false); var img=g.AddComponent<Image>(); img.color=new Color(.03f,.06f,.1f,.8f);
        var btn=g.AddComponent<Button>(); btn.onClick.AddListener(action);
        var r=g.GetComponent<RectTransform>(); r.anchorMin=anchor; r.anchorMax=anchor; r.anchoredPosition=Vector2.zero; r.sizeDelta=size;
        var t=Label(g.transform,value,new Vector2(.5f,.5f),size,18);
    }


    void HoldButtonUI(Transform parent,string value,Vector2 anchor,Vector2 size,float x,float y,bool sprint=false)
    {
        var g=new GameObject(value); g.transform.SetParent(parent,false);
        var img=g.AddComponent<Image>(); img.color=new Color(.03f,.06f,.1f,.8f);
        var r=g.GetComponent<RectTransform>(); r.anchorMin=anchor; r.anchorMax=anchor; r.anchoredPosition=Vector2.zero; r.sizeDelta=size;
        Label(g.transform,value,new Vector2(.5f,.5f),size,18);
        var trigger=g.AddComponent<EventTrigger>();
        var down=new EventTrigger.Entry { eventID=EventTriggerType.PointerDown };
        down.callback.AddListener((data)=>{ if(sprint) UF27PlayerController.Sprinting=true; else { UF27PlayerController.MoveX=x; UF27PlayerController.MoveY=y; } });
        trigger.triggers.Add(down);
        var up=new EventTrigger.Entry { eventID=EventTriggerType.PointerUp };
        up.callback.AddListener((data)=>{ if(sprint) UF27PlayerController.Sprinting=false; else { if(x!=0) UF27PlayerController.MoveX=0; if(y!=0) UF27PlayerController.MoveY=0; } });
        trigger.triggers.Add(up);
        var exit=new EventTrigger.Entry { eventID=EventTriggerType.PointerExit };
        exit.callback.AddListener((data)=>{ if(sprint) UF27PlayerController.Sprinting=false; else { if(x!=0) UF27PlayerController.MoveX=0; if(y!=0) UF27PlayerController.MoveY=0; } });
        trigger.triggers.Add(exit);
    }

    void Update()
    {
        if(matchRunning) matchTime+=Time.deltaTime;
        if(scoreText) scoreText.text=$"BLUE  {homeScore}  -  {awayScore}  RED";
        if(clockText) clockText.text=string.Format("{0:00}:{1:00}",Mathf.FloorToInt(matchTime/60),Mathf.FloorToInt(matchTime%60));
        if(ball && Mathf.Abs(ball.position.z)>17.5f) { if(ball.position.z>0) homeScore++; else awayScore++; ResetPlay(); }
        if(ball && Mathf.Abs(ball.position.x)>11.5f) ResetPlay();
    }

    public void ResetPlay()
    {
        ball.position=new Vector3(0,.5f,0); ballBody.velocity=Vector3.zero; ballBody.angularVelocity=Vector3.zero;
        if(player) player.transform.position=new Vector3(0,1,-5);
    }
}
