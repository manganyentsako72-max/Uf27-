using UnityEngine;

public class UF27PlayerController : MonoBehaviour
{
    public Transform ball;
    public static float MoveX, MoveY;
    public static bool Sprinting;
    float speed=5.5f;

    void Update()
    {
        float x=MoveX, z=MoveY;
#if UNITY_EDITOR || UNITY_STANDALONE
        x=Input.GetAxisRaw("Horizontal"); z=Input.GetAxisRaw("Vertical");
        if(Input.GetKey(KeyCode.LeftShift)) Sprinting=true; else Sprinting=false;
        if(Input.GetKeyDown(KeyCode.Space)) Shoot();
        if(Input.GetKeyDown(KeyCode.E)) Pass();
#endif
        Vector3 move=new Vector3(x,0,z).normalized;
        transform.position+=move*speed*(Sprinting?1.45f:1f)*Time.deltaTime;
        transform.position=new Vector3(Mathf.Clamp(transform.position.x,-10,10),1,Mathf.Clamp(transform.position.z,-15,14));
        if(move.sqrMagnitude>.01f) transform.rotation=Quaternion.LookRotation(move);
    }

    public void Shoot()
    {
        if(!ball) return;
        var rb=ball.GetComponent<Rigidbody>();
        if(Vector3.Distance(transform.position,ball.position)<2.4f)
            rb.AddForce((Vector3.forward*.75f+Vector3.up*.22f)*13f,ForceMode.Impulse);
    }

    public void Pass()
    {
        if(!ball) return;
        var rb=ball.GetComponent<Rigidbody>();
        if(Vector3.Distance(transform.position,ball.position)<2.4f)
            rb.AddForce((Vector3.forward*.5f+Vector3.up*.08f)*7f,ForceMode.Impulse);
    }

    void OnCollisionEnter(Collision c)
    {
        if(c.transform.name=="Match ball" && ball)
        {
            var rb=ball.GetComponent<Rigidbody>();
            rb.AddForce((ball.position-transform.position).normalized*2.5f,ForceMode.Impulse);
        }
    }
}
